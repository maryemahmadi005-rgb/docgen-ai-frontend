from flask import Flask, jsonify

from app.config import get_config
from app.extensions import db, migrate, jwt, cors


def create_app(env_name: str | None = None) -> Flask:
    app = Flask(__name__)
    app.config.from_object(get_config(env_name))

    # --- Extensions ---
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)

    # CORS : autorise le frontend (autre origine/port en dev) à appeler /api/*.
    # Sans ça, le navigateur bloque le preflight OPTIONS et TOUTES les requêtes
    # axios (elles envoient Authorization + Content-Type: application/json,
    # donc sont "non simples" et déclenchent un preflight) échouent en
    # "Network Error" côté frontend, alors que le backend répond correctement.
    cors.init_app(
        app,
        resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}},
        supports_credentials=False,
        expose_headers=["Content-Type"],
        allow_headers=["Content-Type", "Authorization"],
        methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    )

    # --- Modèles (import nécessaire pour qu'Alembic les détecte) ---
    with app.app_context():
        from app import models  # noqa: F401

    # --- Blueprints API ---
    from app.api import register_blueprints
    register_blueprints(app)

    # --- Health check ---
    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok"})

    # --- Handlers d'erreur JSON ---
    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Ressource introuvable"}), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify({"error": "Erreur interne du serveur"}), 500

    return app