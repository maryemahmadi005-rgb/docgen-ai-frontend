from __future__ import annotations

import os

from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.container import get_container
from app.models.repository import SyncMode, SyncMethod
from app.services.git_service import GitServiceError
from app.services.readme_generator import ReadmeGeneratorError
from app.utils.encryption import EncryptionService, EncryptionError

repositories_bp = Blueprint("repositories", __name__, url_prefix="/api/repositories")


@repositories_bp.get("")
@jwt_required()
def list_repositories():
    user_id = get_jwt_identity()
    container = get_container()
    repos = container.repository_repository.find_by_user(user_id)
    return jsonify([r.to_dict() for r in repos])


@repositories_bp.post("")
@jwt_required()
def create_repository():
    user_id = get_jwt_identity()
    data = request.get_json(silent=True) or {}

    github_url = data.get("github_url")
    full_name = data.get("full_name")
    default_branch = data.get("default_branch", "main")

    if not github_url or not full_name:
        return jsonify({"error": "github_url et full_name sont requis"}), 400

    container = get_container()

    if container.repository_repository.find_by_user_and_fullname(user_id, full_name):
        return jsonify({"error": "Ce repository est déjà tracké"}), 409

    repo = container.repository_repository.create(
        user_id=user_id,
        github_url=github_url,
        full_name=full_name,
        default_branch=default_branch,
        sync_mode=SyncMode(data.get("sync_mode", "manual")),
        sync_method=SyncMethod(data.get("sync_method", "webhook")),
    )
    container.commit()

    return jsonify(repo.to_dict()), 201


@repositories_bp.get("/<repo_id>")
@jwt_required()
def get_repository(repo_id: str):
    user_id = get_jwt_identity()
    container = get_container()
    repo = container.repository_repository.get_by_id(repo_id)

    if not repo or repo.user_id != user_id:
        return jsonify({"error": "Repository introuvable"}), 404

    return jsonify(repo.to_dict())


@repositories_bp.patch("/<repo_id>/sync-mode")
@jwt_required()
def update_sync_mode(repo_id: str):
    user_id = get_jwt_identity()
    data = request.get_json(silent=True) or {}
    new_mode = data.get("sync_mode")

    if new_mode not in (SyncMode.manual.value, SyncMode.automatic.value):
        return jsonify({"error": "sync_mode doit être 'manual' ou 'automatic'"}), 400

    container = get_container()
    repo = container.repository_repository.get_by_id(repo_id)

    if not repo or repo.user_id != user_id:
        return jsonify({"error": "Repository introuvable"}), 404

    repo = container.repository_repository.update_sync_mode(repo, SyncMode(new_mode))
    container.commit()

    return jsonify(repo.to_dict())


@repositories_bp.delete("/<repo_id>")
@jwt_required()
def delete_repository(repo_id: str):
    user_id = get_jwt_identity()
    container = get_container()
    repo = container.repository_repository.get_by_id(repo_id)

    if not repo or repo.user_id != user_id:
        return jsonify({"error": "Repository introuvable"}), 404

    container.repository_repository.delete(repo)
    container.commit()

    return "", 204


@repositories_bp.get("/<repo_id>/commits")
@jwt_required()
def list_commits(repo_id: str):
    user_id = get_jwt_identity()
    container = get_container()
    repo = container.repository_repository.get_by_id(repo_id)

    if not repo or repo.user_id != user_id:
        return jsonify({"error": "Repository introuvable"}), 404

    limit = request.args.get("limit", default=50, type=int)
    offset = request.args.get("offset", default=0, type=int)
    commits = container.commit_repository.find_by_repository(repo_id, limit=limit, offset=offset)

    return jsonify([c.to_dict() for c in commits])


@repositories_bp.get("/<repo_id>/analyses/latest")
@jwt_required()
def get_latest_analysis(repo_id: str):
    user_id = get_jwt_identity()
    container = get_container()
    repo = container.repository_repository.get_by_id(repo_id)

    if not repo or repo.user_id != user_id:
        return jsonify({"error": "Repository introuvable"}), 404

    analysis = container.analysis_repository.find_latest_for_repository(repo_id)
    if not analysis:
        return jsonify({"error": "Aucune analyse trouvée"}), 404

    return jsonify(analysis.to_dict())


@repositories_bp.post("/<repo_id>/generate")
@jwt_required()
def generate_readme(repo_id: str):
    """
    Génération initiale du README pour un repository déjà tracké.

    Réutilise le pipeline existant (Phase 1) :
      GitService.clone_repository()
      -> AnalyzerService.analyze()
      -> ReadmeGeneratorService.generate_initial_readme() (AIService/Ollama)
      -> sauvegarde GeneratedReadme + ReadmeVersion (triggered_by=initial_generation)
      -> mise à jour repo.current_readme_version_id / last_synced_commit_sha

    Ne touche pas au SyncOrchestrator ni aux webhooks : c'est bien la même
    étape "génération initiale" que celle utilisée à l'ajout d'un repo,
    simplement déclenchable manuellement a posteriori. Une fois le premier
    README + la première version créés, le monitoring GitHub (webhook/
    polling) peut prendre le relais normalement via SyncOrchestrator.
    """
    user_id = get_jwt_identity()
    container = get_container()

    print(f"🚀 [README] DÉBUT GÉNÉRATION — repo_id={repo_id}")

    repo = container.repository_repository.get_by_id(repo_id)
    if not repo or repo.user_id != user_id:
        print(f"❌ [README] ERREUR — étape=INIT — repo_id={repo_id} — repository introuvable")
        return jsonify({"error": "Repository introuvable"}), 404

    # --- Jeton GitHub optionnel (repos privés) ---
    auth_token = None
    if repo.user and repo.user.github_token:
        try:
            auth_token = EncryptionService().decrypt(repo.user.github_token)
        except EncryptionError as e:
            current_app.logger.warning(
                "Impossible de déchiffrer le token GitHub pour user=%s: %s", user_id, e
            )
            auth_token = None

    # --- 1. Clone ---
    try:
        local_path = container.git_service.clone_repository(
            github_url=repo.github_url,
            repository_id=repo.id,
            auth_token=auth_token,
            # Ne force une branche que si l'utilisateur l'a explicitement
            # renseignée (tracked_branch). "default_branch" vaut "main" par
            # défaut à la création du repo et n'est pas fiable comme nom de
            # branche réel — on laisse GitService détecter la vraie branche
            # par défaut du remote dans ce cas.
            branch=repo.tracked_branch,
        )
        repo.local_clone_path = local_path
        container.session.flush()
    except GitServiceError as e:
        return jsonify({"error": f"Échec du clone du repository: {e}"}), 502

    # --- PREUVE DE CORRESPONDANCE : le clone local doit bien être celui du
    # repo demandé (repo.github_url), et non un ancien clone réutilisé par
    # erreur (ex: reload Flask en pleine copie, chemin resté sur le repo
    # précédent, cache de working dir, etc.) ---
    try:
        origin_url = container.git_service._open_repo(local_path).remotes.origin.url
    except Exception as e:
        origin_url = f"<indisponible: {e}>"
    top_level_entries = sorted(os.listdir(local_path))
    print(f"🔎 [README] VÉRIF CLONE — repo_id={repo.id} — demandé={repo.github_url} — "
          f"origin_réel={origin_url} — local_path={local_path} — "
          f"top_level={top_level_entries}")
    if origin_url and repo.github_url.rstrip("/").rstrip(".git") not in origin_url.rstrip("/").rstrip(".git"):
        print(f"❌ [README] ERREUR — étape=VÉRIF CLONE — repo_id={repo.id} — "
              f"MISMATCH: demandé={repo.github_url} vs origin réel={origin_url}")
        return jsonify({
            "error": (
                f"Le clone local ne correspond pas au repository demandé "
                f"(attendu: {repo.github_url}, trouvé: {origin_url}). "
                f"Génération annulée pour éviter un README incorrect."
            )
        }), 502

    # --- 2. Analyse statique ---
    analysis = container.analyzer_service.analyze(local_path, repository_id=repo.id)

    print(f"🔎 [README] PREUVE ANALYSE — repo_id={repo.id} — "
          f"important_files={analysis.important_files} — "
          f"file_structure_top_level={list(analysis.file_structure.get('.', {}).get('dirs', [])) if isinstance(analysis.file_structure.get('.'), dict) else analysis.file_structure}")

    container.analysis_repository.create(
        repository_id=repo.id,
        languages=analysis.languages,
        frameworks=analysis.frameworks,
        dependencies=analysis.dependencies,
        file_structure=analysis.file_structure,
        important_files=analysis.important_files,
        install_scripts=analysis.install_scripts,
        run_scripts=analysis.run_scripts,
    )

    # --- 3. Génération IA (Ollama) + persistance README/version ---
    try:
        result = container.readme_generator_service.generate_initial_readme(
            repository_id=repo.id,
            project_name=repo.full_name.split("/")[-1],
            analysis=analysis,
        )
    except ReadmeGeneratorError as e:
        container.rollback()
        return jsonify({"error": f"Échec de la génération du README: {e}"}), 502

    # --- 4. Préparer le repo pour le monitoring GitHub (SyncOrchestrator/webhook) ---
    readme_version = result["version"]
    repo.current_readme_version_id = readme_version.id
    try:
        repo.last_synced_commit_sha = container.git_service.get_current_head_sha(local_path)
    except GitServiceError:
        pass  # non bloquant : le README est déjà généré et sauvegardé

    container.commit()

    print(f"🎉 [README] GÉNÉRATION TERMINÉE — repo_id={repo.id}")

    return (
        jsonify(
            {
                "status": "generated",
                "readme": result["readme"].to_dict(),
                "version": readme_version.to_dict(),
                "repository": repo.to_dict(),
            }
        ),
        201,
    )