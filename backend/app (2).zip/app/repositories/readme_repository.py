from __future__ import annotations

from typing import Optional

from sqlalchemy import select

from app.models.generated_readme import GeneratedReadme
from app.repositories.base_repository import BaseRepository


class ReadmeRepository(BaseRepository[GeneratedReadme]):
    model = GeneratedReadme

    def find_by_repository(self, repository_id: str) -> Optional[GeneratedReadme]:
        stmt = select(GeneratedReadme).where(GeneratedReadme.repository_id == repository_id)
        return self.session.scalars(stmt).first()

    def create(
        self,
        repository_id: str,
        sections_json: Optional[dict] = None,
        content_md: Optional[str] = None,
    ) -> GeneratedReadme:
        readme = GeneratedReadme(
            repository_id=repository_id,
            sections_json=sections_json,
            content_md=content_md,
        )
        return self.add(readme)

    def update_content(
        self,
        readme: GeneratedReadme,
        sections_json: dict,
        content_md: str,
        current_version_id: Optional[str] = None,
    ) -> GeneratedReadme:
        readme.sections_json = sections_json
        readme.content_md = content_md
        if current_version_id:
            readme.current_version_id = current_version_id
        self.session.flush()
        return readme
