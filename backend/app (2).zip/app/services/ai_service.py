"""
AI Service — client unique pour Ollama.

Ce service est le seul point de contact avec le LLM dans toute l'application.
Il ne connaît ni git, ni la base de données, ni le README — il reçoit du texte
en entrée et retourne du texte (ou du JSON structuré) en sortie.

Utilisé par :
- diff_analyzer_service.py  → classify_impact()
- readme_updater.py         → generate_section() / generate_full_readme()
"""

import json
import logging
import re
import time
import requests
from typing import Optional

logger = logging.getLogger(__name__)


class AIServiceError(Exception):
    """Levée quand l'appel au modèle échoue ou renvoie une réponse invalide."""
    pass


class AIService:
    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str = "llama3.1",
        timeout: int = 300,
    ):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout

    # ------------------------------------------------------------------
    # Méthode bas niveau — unique point d'appel réseau vers Ollama
    # ------------------------------------------------------------------
    def _call(self, prompt: str, system: Optional[str] = None, temperature: float = 0.3) -> str:
        """
        Appelle Ollama /api/generate et retourne le texte brut de la réponse.
        Lève AIServiceError si l'appel échoue.
        """
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": temperature},
        }
        if system:
            payload["system"] = system

        prompt_chars = len(prompt) + len(system or "")
        print(f"🤖 [README] Appel Ollama — model={self.model} — base_url={self.base_url} — "
              f"prompt_size={prompt_chars} chars — timeout={self.timeout}s")
        t0 = time.monotonic()

        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=self.timeout,
            )
            response.raise_for_status()
        except requests.exceptions.ConnectionError as e:
            elapsed = time.monotonic() - t0
            print(f"❌ [README] ERREUR — Ollama injoignable sur {self.base_url} "
                  f"après {elapsed:.1f}s — vérifie qu'Ollama tourne (`ollama serve`)")
            raise AIServiceError(
                f"Ollama n'est pas joignable sur {self.base_url}. "
                f"Vérifie qu'Ollama est lancé (`ollama serve`) et accessible."
            ) from e
        except requests.exceptions.Timeout as e:
            elapsed = time.monotonic() - t0
            print(f"❌ [README] ERREUR — Timeout Ollama après {elapsed:.1f}s "
                  f"(timeout configuré={self.timeout}s, model={self.model})")
            raise AIServiceError(
                f"Ollama n'a pas répondu dans le délai imparti ({self.timeout}s) "
                f"avec le modèle '{self.model}'. Le prompt fait {prompt_chars} caractères — "
                f"augmente OLLAMA_TIMEOUT si le modèle/la machine est lent(e)."
            ) from e
        except requests.RequestException as e:
            elapsed = time.monotonic() - t0
            print(f"❌ [README] ERREUR — appel Ollama échoué après {elapsed:.1f}s — {e}")
            logger.error(f"AIService: échec appel Ollama — {e}")
            raise AIServiceError(f"Impossible de contacter le modèle IA: {e}") from e

        data = response.json()
        text = data.get("response", "").strip()
        elapsed = time.monotonic() - t0

        if not text:
            print(f"❌ [README] ERREUR — Ollama a répondu vide après {elapsed:.1f}s "
                  f"(model={self.model} introuvable ?)")
            raise AIServiceError(
                f"Le modèle '{self.model}' a retourné une réponse vide "
                f"— vérifie qu'il est bien installé (`ollama pull {self.model}`)."
            )

        print(f"✅ [README] Réponse Ollama reçue en {elapsed:.1f}s — model={self.model} — "
              f"response_size={len(text)} chars")

        return text

    def _extract_json(self, raw: str) -> dict:
        """
        Parsing robuste de la réponse Ollama. Le modèle n'est jamais
        garanti de retourner du JSON pur — il peut ajouter du texte avant/
        après, entourer le JSON d'un bloc ```json ... ```, ou (plus
        problématique) produire un JSON syntaxiquement invalide (virgule
        manquante, guillemet non échappé, réponse tronquée).

        Étapes, dans l'ordre, sans jamais inventer de contenu, sans
        remplacement global de caractères, sans suppression arbitraire :
          1. json.loads() direct sur la réponse strippée (cas nominal).
          2. Si un bloc ```json ... ``` / ``` ... ``` est présent, on
             retire uniquement les fences markdown (rien d'autre) et on
             retente json.loads() sur le contenu.
          3. json.JSONDecoder().raw_decode() à partir de la première
             accolade '{' trouvée : récupère le premier objet JSON complet
             même s'il y a du texte parasite avant/après (mais ne répare
             PAS un objet syntaxiquement cassé au milieu).
          4. Si tout échoue, on lève json.JSONDecodeError (laissé remonter
             tel quel à l'appelant, qui décide de la stratégie de retry).
        """
        stripped = raw.strip()
        last_error: Optional[json.JSONDecodeError] = None
        last_candidate = stripped

        # --- 1. Cas nominal : JSON pur ---
        try:
            return json.loads(stripped)
        except json.JSONDecodeError as e:
            last_error = e
            last_candidate = stripped

        # --- 2. Suppression UNIQUEMENT des fences markdown ```json ... ``` ---
        fence_match = re.search(r"```(?:json)?\s*(.*?)\s*```", raw, re.DOTALL)
        if fence_match:
            candidate = fence_match.group(1).strip()
            try:
                return json.loads(candidate)
            except json.JSONDecodeError as e:
                last_error = e
                last_candidate = candidate
        else:
            candidate = stripped

        # --- 3. Premier objet JSON complet, en ignorant le texte parasite
        #        avant/après (ex: "Voici le JSON: {...} J'espère que ça aide") ---
        first_brace = candidate.find("{")
        if first_brace != -1:
            try:
                obj, _end_index = json.JSONDecoder().raw_decode(candidate, first_brace)
                return obj
            except json.JSONDecodeError as e:
                last_error = e
                last_candidate = candidate

        # --- 4. Échec : on remonte l'erreur de parsing telle quelle,
        #        l'appelant (_call_json) gère le retry / l'erreur finale. ---
        raise last_error

    def _call_json(self, prompt: str, system: Optional[str] = None) -> dict:
        """
        Variante qui force une sortie JSON et la parse.
        Utilisée quand on a besoin d'une structure exploitable directement
        (ex: classification d'impact, génération du README).

        Robustesse : si la première réponse n'est pas un JSON exploitable,
        UNE seule nouvelle tentative est faite en renvoyant l'erreur de
        syntaxe exacte au modèle et en lui demandant de ne corriger QUE la
        syntaxe JSON (pas de remplacement de caractères côté code, pas de
        contenu inventé — c'est le modèle qui corrige, pas nous).
        """
        json_instruction = (
            "\n\nIMPORTANT: Réponds UNIQUEMENT avec un objet JSON valide, "
            "sans texte avant ni après, sans balises markdown, sans ```json."
        )
        raw = self._call(prompt + json_instruction, system=system, temperature=0.1)

        print("🤖 [AI] JSON PARSE START")
        try:
            parsed = self._extract_json(raw)
        except json.JSONDecodeError as first_error:
            print(f"⚠️ [AI] JSON INVALID — RETRY — {first_error}")
            logger.warning(f"AIService: JSON invalide (1ère tentative) — {first_error} — réponse brute:\n{raw}")

            retry_prompt = (
                "La réponse JSON suivante est syntaxiquement invalide et ne peut "
                "pas être parsée par json.loads().\n\n"
                f"Erreur exacte: {first_error.msg} à la ligne {first_error.lineno}, "
                f"colonne {first_error.colno} (caractère {first_error.pos}).\n\n"
                "Voici la réponse invalide:\n"
                f"{raw}\n\n"
                "Corrige UNIQUEMENT la syntaxe JSON (virgules manquantes, "
                "accolades/crochets non fermés, guillemets non échappés, etc.). "
                "Ne change ni les clés, ni les valeurs, ni le contenu. "
                "Réponds UNIQUEMENT avec l'objet JSON corrigé, sans texte avant "
                "ni après, sans balises markdown, sans ```json."
            )
            retry_raw = self._call(retry_prompt, system=system, temperature=0.1)

            try:
                parsed = self._extract_json(retry_raw)
            except json.JSONDecodeError as second_error:
                print(f"❌ [AI] JSON PARSE FAILED — {second_error}")
                logger.error(
                    f"AIService: JSON invalide après retry — {second_error} — "
                    f"réponse brute (retry):\n{retry_raw}"
                )
                pos = second_error.pos
                start = max(0, pos - 80)
                end = min(len(retry_raw), pos + 80)
                context = retry_raw[start:end]
                raise AIServiceError(
                    f"Le modèle a retourné un JSON invalide, même après une "
                    f"tentative de correction ({second_error.msg} à la ligne "
                    f"{second_error.lineno}, colonne {second_error.colno}). "
                    f"Contexte: '...{context}...'"
                ) from second_error

            print("🤖 [AI] JSON RETRY SUCCESS")
            return parsed

        print("🤖 [AI] JSON PARSE SUCCESS")
        return parsed

    # ------------------------------------------------------------------
    # Méthodes métier — utilisées par Diff Analyzer
    # ------------------------------------------------------------------
    def classify_impact(self, file_changes: list[dict], repo_context: str = "") -> dict:
        """
        Détermine, pour des changements de fichiers non couverts par les règles
        statiques (impact_rules.py), quelles sections du README sont affectées.

        file_changes: liste de dicts {path, change_type, diff_excerpt}
        Retourne: {"impact_category": str, "affected_sections": list[str], "confidence_score": float}
        """
        files_description = "\n".join(
            f"- {fc['path']} ({fc['change_type']}): {fc.get('diff_excerpt', '')[:300]}"
            for fc in file_changes
        )

        system = (
            "Tu es un assistant qui analyse des changements de code pour déterminer "
            "s'ils doivent déclencher une mise à jour du README d'un projet. "
            "Les sections possibles d'un README sont: features, installation, usage, "
            "technologies, project_structure, configuration, license. "
            "Sois conservateur: si le changement n'a aucun impact visible pour un "
            "utilisateur du projet (ex: refactor interne, tests, typo), retourne une liste vide."
        )

        prompt = f"""Voici les fichiers modifiés dans un commit:

{files_description}

Contexte du projet: {repo_context or "non spécifié"}

Retourne un JSON avec exactement ces clés:
{{
  "impact_category": "feature" | "dependency" | "structure" | "config" | "license" | "none",
  "affected_sections": ["features", "installation", ...],
  "confidence_score": 0.0 à 1.0
}}"""

        result = self._call_json(prompt, system=system)

        # Validation minimale de la structure retournée
        result.setdefault("impact_category", "none")
        result.setdefault("affected_sections", [])
        result.setdefault("confidence_score", 0.0)

        return result

    # ------------------------------------------------------------------
    # Méthodes métier — utilisées par README Updater
    # ------------------------------------------------------------------
    def generate_section(
        self,
        section_name: str,
        old_content,
        relevant_files: list[dict],
    ):
        """
        Régénère UNE section précise du README en tenant compte du changement.
        old_content peut être une string ou une liste (ex: features).
        Retourne le même type de structure que old_content.
        """
        is_list = isinstance(old_content, list)
        old_repr = "\n".join(f"- {item}" for item in old_content) if is_list else str(old_content)

        files_description = "\n".join(
            f"- {fc['path']} ({fc['change_type']}): {fc.get('diff_excerpt', '')[:300]}"
            for fc in relevant_files
        )

        system = (
            f"Tu réécris uniquement la section '{section_name}' d'un README GitHub. "
            "Garde le même style, le même format et la même longueur relative que l'existant. "
            "N'ajoute aucun commentaire, aucune explication — retourne uniquement le contenu "
            "de la section, prêt à être inséré tel quel."
        )

        prompt = f"""Section actuelle '{section_name}':
{old_repr}

Changements de code pertinents:
{files_description}

Réécris la section '{section_name}' en intégrant ce changement si nécessaire.
Si le changement ne justifie aucune modification réelle du contenu, retourne
exactement le contenu existant sans le modifier."""

        raw = self._call(prompt, system=system, temperature=0.3)

        if is_list:
            # Parse une liste à puces retournée en texte
            lines = [
                line.lstrip("-•* ").strip()
                for line in raw.splitlines()
                if line.strip()
            ]
            return lines if lines else old_content

        return raw.strip()

    def generate_full_readme(self, project_context: dict, repository_id: str | None = None) -> dict:
        """
        Génération initiale complète (Phase 1) — utilisée uniquement par
        readme_generator.py, jamais par readme_updater.py.

        project_context: résultat de l'AnalyzerService (langages, frameworks,
        dépendances, structure, scripts, infos git...)

        repository_id: uniquement utilisé pour le logging (traçabilité du
        workflow) — n'affecte aucune logique métier.

        Retourne un dict correspondant au sections_json complet.
        """
        print(f"🤖 [README] OLLAMA START — repo_id={repository_id} — model={self.model}")

        system = (
            "Tu es un générateur de README professionnel pour projets GitHub. "
            "Tu écris un README clair, concis, dans le style des meilleurs projets "
            "open source. Tu ne génères PAS de documentation technique exhaustive, "
            "uniquement un README standard."
        )

        prompt = f"""Voici l'analyse d'un projet:

Langages: {project_context.get('languages')}
Frameworks: {project_context.get('frameworks')}
Dépendances: {project_context.get('dependencies')}
Structure des fichiers: {project_context.get('file_structure')}
Scripts d'installation: {project_context.get('install_scripts')}
Scripts d'exécution: {project_context.get('run_scripts')}

Génère un JSON avec exactement ces clés:
{{
  "title": "...",
  "description": "...",
  "features": ["...", "..."],
  "installation": "...",
  "usage": "...",
  "technologies": ["...", "..."],
  "project_structure": "...",
  "configuration": "...",
  "license": "..."
}}"""

        try:
            result = self._call_json(prompt, system=system)
        except AIServiceError as e:
            print(f"❌ [README] ERREUR — étape=OLLAMA — repo_id={repository_id} — {e}")
            raise
        print(f"✅ [README] OLLAMA TERMINÉ — repo_id={repository_id}")


        required_keys = [
            "title", "description", "features", "installation", "usage",
            "technologies", "project_structure", "configuration", "license",
        ]
        for key in required_keys:
            result.setdefault(key, "" if key not in ("features", "technologies") else [])

        return result