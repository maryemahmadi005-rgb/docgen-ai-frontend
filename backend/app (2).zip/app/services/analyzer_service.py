"""
Analyzer Service — scan complet d'un repository (Phase 1).

Extrait : langages, frameworks, dépendances, structure de fichiers,
fichiers importants, scripts d'installation/exécution.

Ce service lit uniquement le filesystem du clone local — aucun appel IA,
aucun accès réseau. C'est du pur parsing/heuristique.
"""

import os
import json
import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

LANGUAGE_EXTENSIONS = {
    ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript", ".jsx": "JavaScript",
    ".tsx": "TypeScript", ".go": "Go", ".rb": "Ruby", ".java": "Java",
    ".php": "PHP", ".rs": "Rust", ".c": "C", ".cpp": "C++", ".cs": "C#",
}

FRAMEWORK_SIGNATURES = {
    "package.json": {"react": "React", "vue": "Vue.js", "express": "Express",
                      "next": "Next.js", "@angular/core": "Angular"},
    "requirements.txt": {"flask": "Flask", "django": "Django", "fastapi": "FastAPI"},
    "pyproject.toml": {"flask": "Flask", "django": "Django", "fastapi": "FastAPI"},
}

IMPORTANT_FILES = [
    "README.md", "LICENSE", "Dockerfile", "docker-compose.yml",
    ".env.example", "Makefile", "package.json", "requirements.txt",
    "pyproject.toml", "go.mod", "Gemfile",
]

IGNORED_DIRS = {".git", "node_modules", "__pycache__", "venv", ".venv", "dist", "build"}


@dataclass
class ProjectAnalysis:
    languages: dict = field(default_factory=dict)          # {"Python": 42, "JavaScript": 10} (nb fichiers)
    frameworks: list = field(default_factory=list)
    dependencies: dict = field(default_factory=dict)        # {package_manager: [deps]}
    file_structure: dict = field(default_factory=dict)      # arbre simplifié top-level
    important_files: list = field(default_factory=list)
    install_scripts: list = field(default_factory=list)
    run_scripts: list = field(default_factory=list)


class AnalyzerService:
    def analyze(self, local_path: str, repository_id: str | None = None) -> ProjectAnalysis:
        print(f"🔍 [README] ANALYSE START — repo_id={repository_id} — path={local_path}")

        try:
            analysis = ProjectAnalysis()

            analysis.languages = self._detect_languages(local_path)
            analysis.important_files = self._find_important_files(local_path)
            analysis.frameworks = self._detect_frameworks(local_path, analysis.important_files)
            analysis.dependencies = self._extract_dependencies(local_path, analysis.important_files)
            analysis.file_structure = self._build_file_structure(local_path)
            analysis.install_scripts, analysis.run_scripts = self._detect_scripts(local_path, analysis.important_files)
        except Exception as e:
            print(f"❌ [README] ERREUR — étape=ANALYSE — repo_id={repository_id} — {e}")
            raise

        print(f"✅ [README] ANALYSE TERMINÉE — repo_id={repository_id} — "
              f"langages={list(analysis.languages.keys())} — frameworks={analysis.frameworks}")
        return analysis

    def _detect_languages(self, local_path: str) -> dict:
        counts: dict[str, int] = {}
        for root, dirs, files in os.walk(local_path):
            dirs[:] = [d for d in dirs if d not in IGNORED_DIRS]
            for f in files:
                ext = os.path.splitext(f)[1]
                lang = LANGUAGE_EXTENSIONS.get(ext)
                if lang:
                    counts[lang] = counts.get(lang, 0) + 1
        return dict(sorted(counts.items(), key=lambda x: -x[1]))

    def _find_important_files(self, local_path: str) -> list:
        found = []
        for filename in IMPORTANT_FILES:
            if os.path.exists(os.path.join(local_path, filename)):
                found.append(filename)
        return found

    def _detect_frameworks(self, local_path: str, important_files: list) -> list:
        frameworks = set()
        for filename, signatures in FRAMEWORK_SIGNATURES.items():
            if filename not in important_files:
                continue
            content = self._read_file_safe(os.path.join(local_path, filename))
            if not content:
                continue
            for signature, framework_name in signatures.items():
                if signature in content.lower():
                    frameworks.add(framework_name)
        return sorted(frameworks)

    def _extract_dependencies(self, local_path: str, important_files: list) -> dict:
        deps = {}

        if "package.json" in important_files:
            content = self._read_file_safe(os.path.join(local_path, "package.json"))
            try:
                data = json.loads(content)
                deps["npm"] = list(data.get("dependencies", {}).keys())
            except (json.JSONDecodeError, TypeError):
                pass

        if "requirements.txt" in important_files:
            content = self._read_file_safe(os.path.join(local_path, "requirements.txt"))
            if content:
                deps["pip"] = [
                    line.split("==")[0].split(">=")[0].strip()
                    for line in content.splitlines()
                    if line.strip() and not line.startswith("#")
                ]

        return deps

    def _build_file_structure(self, local_path: str, max_depth: int = 2) -> dict:
        structure = {}
        base_depth = local_path.rstrip(os.sep).count(os.sep)

        for root, dirs, files in os.walk(local_path):
            dirs[:] = [d for d in dirs if d not in IGNORED_DIRS]
            depth = root.rstrip(os.sep).count(os.sep) - base_depth
            if depth >= max_depth:
                dirs[:] = []
                continue
            rel_path = os.path.relpath(root, local_path)
            structure[rel_path] = {"dirs": dirs[:], "files": [f for f in files if not f.startswith(".")]}

        return structure

    def _detect_scripts(self, local_path: str, important_files: list) -> tuple[list, list]:
        install_scripts, run_scripts = [], []

        if "package.json" in important_files:
            content = self._read_file_safe(os.path.join(local_path, "package.json"))
            try:
                data = json.loads(content)
                scripts = data.get("scripts", {})
                if "start" in scripts:
                    run_scripts.append("npm start")
                if "dev" in scripts:
                    run_scripts.append("npm run dev")
                install_scripts.append("npm install")
            except (json.JSONDecodeError, TypeError):
                pass

        if "requirements.txt" in important_files:
            install_scripts.append("pip install -r requirements.txt")

        if "Makefile" in important_files:
            install_scripts.append("make install")

        if "Dockerfile" in important_files:
            run_scripts.append("docker build . && docker run <image>")

        return install_scripts, run_scripts

    def _read_file_safe(self, path: str) -> str:
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()
        except (IOError, OSError):
            return ""