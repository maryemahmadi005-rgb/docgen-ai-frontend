"""
README Generator — Phase 1, génération initiale complète.

Distinct de readme_updater.py : ce service ne fait PAS de patch partiel,
il produit le README complet à partir de zéro, une seule fois,
au moment où le repository est ajouté.
"""

import logging

from app.services.ai_service import AIService, AIServiceError
from app.services.analyzer_service import ProjectAnalysis
from app.models.readme_version import TriggeredBy
from app.services.markdown_renderer import render_readme

logger = logging.getLogger(__name__)


class ReadmeGeneratorError(Exception):
    pass


class ReadmeGeneratorService:
    def __init__(self, ai_service: AIService, readme_repository, readme_version_repository):
        self.ai_service = ai_service
        self.readme_repository = readme_repository
        self.readme_version_repository = readme_version_repository

    def generate_initial_readme(self, repository_id: str, project_name: str, analysis: ProjectAnalysis) -> dict:
        """
        Génère et persiste le premier README d'un repository.
        Retourne le sections_json généré.
        """
        project_context = {
            "project_name": project_name,
            "languages": analysis.languages,
            "frameworks": analysis.frameworks,
            "dependencies": analysis.dependencies,
            "file_structure": analysis.file_structure,
            "install_scripts": analysis.install_scripts,
            "run_scripts": analysis.run_scripts,
        }

        try:
            sections_json = self.ai_service.generate_full_readme(project_context, repository_id=repository_id)
        except AIServiceError as e:
            print(f"❌ [README] ERREUR — étape=OLLAMA — repo_id={repository_id} — {e}")
            logger.error(f"Échec génération README initial pour repo {repository_id}: {e}")
            raise ReadmeGeneratorError(f"Impossible de générer le README initial: {e}") from e

        rendered_md = render_readme(sections_json)
        print(f"📝 [README] README GÉNÉRÉ — repo_id={repository_id}")

        try:
            print(f"💾 [README] SAUVEGARDE DB — repo_id={repository_id}")
            readme = self.readme_repository.get_or_create_for_repository(
                repository_id=repository_id,
                sections_json=sections_json,
                content_md=rendered_md,
            )

            version = self.readme_version_repository.create_next_version(
                readme_id=readme.id,
                sections_json=sections_json,
                content_md=rendered_md,
                triggered_by=TriggeredBy.initial_generation,
            )

            self.readme_repository.update_content(
                readme, sections_json, rendered_md, current_version_id=version.id
            )
        except Exception as e:
            print(f"❌ [README] ERREUR — étape=SAUVEGARDE DB — repo_id={repository_id} — {e}")
            raise

        return {"sections_json": sections_json, "readme": readme, "version": version}