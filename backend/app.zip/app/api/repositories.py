from __future__ import annotations

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.container import get_container
from app.models.repository import SyncMode, SyncMethod

repositories_bp = Blueprint("repositories", __name__, url_prefix="/api/repositories")


@repositories_bp.get("")
@jwt_required()
def list_repositories():
    user_id = get_jwt_identity()
    container = get_container()
    repos = container.repository_repository.find_by_user(user_id)
    return jsonify([r.to_dict() for r in repos])


@repositories_bp.post("")
@jwt_required()
def create_repository():
    user_id = get_jwt_identity()
    data = request.get_json(silent=True) or {}

    github_url = data.get("github_url")
    full_name = data.get("full_name")
    default_branch = data.get("default_branch", "main")

    if not github_url or not full_name:
        return jsonify({"error": "github_url et full_name sont requis"}), 400

    container = get_container()

    if container.repository_repository.find_by_user_and_fullname(user_id, full_name):
        return jsonify({"error": "Ce repository est déjà tracké"}), 409

    repo = container.repository_repository.create(
        user_id=user_id,
        github_url=github_url,
        full_name=full_name,
        default_branch=default_branch,
        sync_mode=SyncMode(data.get("sync_mode", "manual")),
        sync_method=SyncMethod(data.get("sync_method", "webhook")),
    )
    container.commit()

    return jsonify(repo.to_dict()), 201


@repositories_bp.get("/<repo_id>")
@jwt_required()
def get_repository(repo_id: str):
    user_id = get_jwt_identity()
    container = get_container()
    repo = container.repository_repository.get_by_id(repo_id)

    if not repo or repo.user_id != user_id:
        return jsonify({"error": "Repository introuvable"}), 404

    return jsonify(repo.to_dict())


@repositories_bp.patch("/<repo_id>/sync-mode")
@jwt_required()
def update_sync_mode(repo_id: str):
    user_id = get_jwt_identity()
    data = request.get_json(silent=True) or {}
    new_mode = data.get("sync_mode")

    if new_mode not in (SyncMode.manual.value, SyncMode.automatic.value):
        return jsonify({"error": "sync_mode doit être 'manual' ou 'automatic'"}), 400

    container = get_container()
    repo = container.repository_repository.get_by_id(repo_id)

    if not repo or repo.user_id != user_id:
        return jsonify({"error": "Repository introuvable"}), 404

    repo = container.repository_repository.update_sync_mode(repo, SyncMode(new_mode))
    container.commit()

    return jsonify(repo.to_dict())


@repositories_bp.delete("/<repo_id>")
@jwt_required()
def delete_repository(repo_id: str):
    user_id = get_jwt_identity()
    container = get_container()
    repo = container.repository_repository.get_by_id(repo_id)

    if not repo or repo.user_id != user_id:
        return jsonify({"error": "Repository introuvable"}), 404

    container.repository_repository.delete(repo)
    container.commit()

    return "", 204


@repositories_bp.get("/<repo_id>/commits")
@jwt_required()
def list_commits(repo_id: str):
    user_id = get_jwt_identity()
    container = get_container()
    repo = container.repository_repository.get_by_id(repo_id)

    if not repo or repo.user_id != user_id:
        return jsonify({"error": "Repository introuvable"}), 404

    limit = request.args.get("limit", default=50, type=int)
    offset = request.args.get("offset", default=0, type=int)
    commits = container.commit_repository.find_by_repository(repo_id, limit=limit, offset=offset)

    return jsonify([c.to_dict() for c in commits])


@repositories_bp.get("/<repo_id>/analyses/latest")
@jwt_required()
def get_latest_analysis(repo_id: str):
    user_id = get_jwt_identity()
    container = get_container()
    repo = container.repository_repository.get_by_id(repo_id)

    if not repo or repo.user_id != user_id:
        return jsonify({"error": "Repository introuvable"}), 404

    analysis = container.analysis_repository.find_latest_for_repository(repo_id)
    if not analysis:
        return jsonify({"error": "Aucune analyse trouvée"}), 404

    return jsonify(analysis.to_dict())
