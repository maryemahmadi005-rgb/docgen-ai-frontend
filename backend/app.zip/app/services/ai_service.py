"""
AI Service — client unique pour Ollama.

Ce service est le seul point de contact avec le LLM dans toute l'application.
Il ne connaît ni git, ni la base de données, ni le README — il reçoit du texte
en entrée et retourne du texte (ou du JSON structuré) en sortie.

Utilisé par :
- diff_analyzer_service.py  → classify_impact()
- readme_updater.py         → generate_section() / generate_full_readme()
"""

import json
import logging
import requests
from typing import Optional

logger = logging.getLogger(__name__)


class AIServiceError(Exception):
    """Levée quand l'appel au modèle échoue ou renvoie une réponse invalide."""
    pass


class AIService:
    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str = "llama3.1",
        timeout: int = 60,
    ):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout

    # ------------------------------------------------------------------
    # Méthode bas niveau — unique point d'appel réseau vers Ollama
    # ------------------------------------------------------------------
    def _call(self, prompt: str, system: Optional[str] = None, temperature: float = 0.3) -> str:
        """
        Appelle Ollama /api/generate et retourne le texte brut de la réponse.
        Lève AIServiceError si l'appel échoue.
        """
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": temperature},
        }
        if system:
            payload["system"] = system

        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=self.timeout,
            )
            response.raise_for_status()
        except requests.RequestException as e:
            logger.error(f"AIService: échec appel Ollama — {e}")
            raise AIServiceError(f"Impossible de contacter le modèle IA: {e}") from e

        data = response.json()
        text = data.get("response", "").strip()

        if not text:
            raise AIServiceError("Le modèle a retourné une réponse vide.")

        return text

    def _call_json(self, prompt: str, system: Optional[str] = None) -> dict:
        """
        Variante qui force une sortie JSON et la parse.
        Utilisée quand on a besoin d'une structure exploitable directement
        (ex: classification d'impact).
        """
        json_instruction = (
            "\n\nIMPORTANT: Réponds UNIQUEMENT avec un objet JSON valide, "
            "sans texte avant ni après, sans balises markdown, sans ```json."
        )
        raw = self._call(prompt + json_instruction, system=system, temperature=0.1)

        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.strip("`")
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
        cleaned = cleaned.strip()

        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            logger.error(f"AIService: JSON invalide retourné par le modèle — {raw}")
            raise AIServiceError(f"Réponse JSON invalide du modèle: {e}") from e

    # ------------------------------------------------------------------
    # Méthodes métier — utilisées par Diff Analyzer
    # ------------------------------------------------------------------
    def classify_impact(self, file_changes: list[dict], repo_context: str = "") -> dict:
        """
        Détermine, pour des changements de fichiers non couverts par les règles
        statiques (impact_rules.py), quelles sections du README sont affectées.

        file_changes: liste de dicts {path, change_type, diff_excerpt}
        Retourne: {"impact_category": str, "affected_sections": list[str], "confidence_score": float}
        """
        files_description = "\n".join(
            f"- {fc['path']} ({fc['change_type']}): {fc.get('diff_excerpt', '')[:300]}"
            for fc in file_changes
        )

        system = (
            "Tu es un assistant qui analyse des changements de code pour déterminer "
            "s'ils doivent déclencher une mise à jour du README d'un projet. "
            "Les sections possibles d'un README sont: features, installation, usage, "
            "technologies, project_structure, configuration, license. "
            "Sois conservateur: si le changement n'a aucun impact visible pour un "
            "utilisateur du projet (ex: refactor interne, tests, typo), retourne une liste vide."
        )

        prompt = f"""Voici les fichiers modifiés dans un commit:

{files_description}

Contexte du projet: {repo_context or "non spécifié"}

Retourne un JSON avec exactement ces clés:
{{
  "impact_category": "feature" | "dependency" | "structure" | "config" | "license" | "none",
  "affected_sections": ["features", "installation", ...],
  "confidence_score": 0.0 à 1.0
}}"""

        result = self._call_json(prompt, system=system)

        # Validation minimale de la structure retournée
        result.setdefault("impact_category", "none")
        result.setdefault("affected_sections", [])
        result.setdefault("confidence_score", 0.0)

        return result

    # ------------------------------------------------------------------
    # Méthodes métier — utilisées par README Updater
    # ------------------------------------------------------------------
    def generate_section(
        self,
        section_name: str,
        old_content,
        relevant_files: list[dict],
    ):
        """
        Régénère UNE section précise du README en tenant compte du changement.
        old_content peut être une string ou une liste (ex: features).
        Retourne le même type de structure que old_content.
        """
        is_list = isinstance(old_content, list)
        old_repr = "\n".join(f"- {item}" for item in old_content) if is_list else str(old_content)

        files_description = "\n".join(
            f"- {fc['path']} ({fc['change_type']}): {fc.get('diff_excerpt', '')[:300]}"
            for fc in relevant_files
        )

        system = (
            f"Tu réécris uniquement la section '{section_name}' d'un README GitHub. "
            "Garde le même style, le même format et la même longueur relative que l'existant. "
            "N'ajoute aucun commentaire, aucune explication — retourne uniquement le contenu "
            "de la section, prêt à être inséré tel quel."
        )

        prompt = f"""Section actuelle '{section_name}':
{old_repr}

Changements de code pertinents:
{files_description}

Réécris la section '{section_name}' en intégrant ce changement si nécessaire.
Si le changement ne justifie aucune modification réelle du contenu, retourne
exactement le contenu existant sans le modifier."""

        raw = self._call(prompt, system=system, temperature=0.3)

        if is_list:
            # Parse une liste à puces retournée en texte
            lines = [
                line.lstrip("-•* ").strip()
                for line in raw.splitlines()
                if line.strip()
            ]
            return lines if lines else old_content

        return raw.strip()

    def generate_full_readme(self, project_context: dict) -> dict:
        """
        Génération initiale complète (Phase 1) — utilisée uniquement par
        readme_generator.py, jamais par readme_updater.py.

        project_context: résultat de l'AnalyzerService (langages, frameworks,
        dépendances, structure, scripts, infos git...)

        Retourne un dict correspondant au sections_json complet.
        """
        system = (
            "Tu es un générateur de README professionnel pour projets GitHub. "
            "Tu écris un README clair, concis, dans le style des meilleurs projets "
            "open source. Tu ne génères PAS de documentation technique exhaustive, "
            "uniquement un README standard."
        )

        prompt = f"""Voici l'analyse d'un projet:

Langages: {project_context.get('languages')}
Frameworks: {project_context.get('frameworks')}
Dépendances: {project_context.get('dependencies')}
Structure des fichiers: {project_context.get('file_structure')}
Scripts d'installation: {project_context.get('install_scripts')}
Scripts d'exécution: {project_context.get('run_scripts')}

Génère un JSON avec exactement ces clés:
{{
  "title": "...",
  "description": "...",
  "features": ["...", "..."],
  "installation": "...",
  "usage": "...",
  "technologies": ["...", "..."],
  "project_structure": "...",
  "configuration": "...",
  "license": "..."
}}"""

        result = self._call_json(prompt, system=system)

        required_keys = [
            "title", "description", "features", "installation", "usage",
            "technologies", "project_structure", "configuration", "license",
        ]
        for key in required_keys:
            result.setdefault(key, "" if key not in ("features", "technologies") else [])

        return result