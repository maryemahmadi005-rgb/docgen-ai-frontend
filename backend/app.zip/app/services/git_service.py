"""
Git Service — wrapper autour de GitPython.

Responsable de toutes les opérations git bas niveau :
clone, fetch, diff, commit, push.

Ce service ne connaît AUCUNE logique métier (pas d'IA, pas de notion
de "section README", pas de sync_mode). Il expose des primitives
réutilisables par Repository Service (clone initial) et par
Commit Detector / Sync Orchestrator (fetch, diff, commit, push).
"""

import os
import logging
from dataclasses import dataclass
from typing import Optional

from git import Repo, GitCommandError
from git.exc import InvalidGitRepositoryError, NoSuchPathError

logger = logging.getLogger(__name__)


class GitServiceError(Exception):
    """Levée pour toute erreur d'opération git."""
    pass


@dataclass
class FileChange:
    path: str
    change_type: str  # 'added' | 'modified' | 'deleted' | 'renamed'
    diff_excerpt: str  # extrait du patch, tronqué


class GitService:
    def __init__(self, clones_base_dir: str = "/data/repo_clones"):
        self.clones_base_dir = clones_base_dir
        os.makedirs(self.clones_base_dir, exist_ok=True)

    # ------------------------------------------------------------------
    # Clone initial (utilisé par Repository Service, Phase 1)
    # ------------------------------------------------------------------
    def clone_repository(
        self,
        github_url: str,
        repository_id: str,
        auth_token: Optional[str] = None,
        branch: Optional[str] = None,
    ) -> str:
        """
        Clone un repository GitHub localement.
        Retourne le chemin local du clone.

        auth_token: nécessaire pour les repos privés — injecté dans l'URL.
        """
        local_path = os.path.join(self.clones_base_dir, str(repository_id))

        if os.path.exists(local_path):
            logger.warning(f"Clone déjà existant pour {repository_id}, suppression avant re-clone.")
            self._remove_directory(local_path)

        clone_url = self._build_authenticated_url(github_url, auth_token)

        try:
            kwargs = {"branch": branch} if branch else {}
            Repo.clone_from(clone_url, local_path, **kwargs)
        except GitCommandError as e:
            logger.error(f"Échec du clone pour {github_url}: {e}")
            raise GitServiceError(f"Impossible de cloner le repository: {e}") from e

        return local_path

    def _build_authenticated_url(self, github_url: str, auth_token: Optional[str]) -> str:
        if not auth_token:
            return github_url
        if github_url.startswith("https://"):
            return github_url.replace("https://", f"https://x-access-token:{auth_token}@")
        return github_url

    def _remove_directory(self, path: str):
        import shutil
        shutil.rmtree(path, ignore_errors=True)

    # ------------------------------------------------------------------
    # Fetch — mise à jour du clone local avant analyse de diff
    # ------------------------------------------------------------------
    def fetch(self, local_path: str, auth_token: Optional[str] = None) -> None:
        """
        Récupère les derniers commits depuis le remote, sans les fusionner.
        """
        repo = self._open_repo(local_path)

        try:
            origin = repo.remotes.origin
            if auth_token:
                self._inject_token_in_remote(repo, auth_token)
            origin.fetch()
        except GitCommandError as e:
            logger.error(f"Échec du fetch sur {local_path}: {e}")
            raise GitServiceError(f"Impossible de fetch le repository: {e}") from e

    def _inject_token_in_remote(self, repo: Repo, auth_token: str):
        origin_url = repo.remotes.origin.url
        if origin_url.startswith("https://") and "x-access-token" not in origin_url:
            authenticated = origin_url.replace("https://", f"https://x-access-token:{auth_token}@")
            repo.remotes.origin.set_url(authenticated)

    # ------------------------------------------------------------------
    # Diff — cœur de la Phase 2
    # ------------------------------------------------------------------
    def get_diff(
        self,
        local_path: str,
        before_sha: str,
        after_sha: str,
        exclude_paths: Optional[list[str]] = None,
    ) -> list[FileChange]:
        """
        Calcule le diff entre deux commits.

        exclude_paths: fichiers à ignorer systématiquement (ex: README.md,
        pour éviter que le bot ne s'auto-déclenche — voir Commit Detector).

        Retourne une liste structurée de FileChange.
        """
        repo = self._open_repo(local_path)
        exclude_paths = exclude_paths or []

        try:
            diff_index = repo.git.diff(
                before_sha, after_sha, name_status=True
            )
        except GitCommandError as e:
            logger.error(f"Échec du diff {before_sha}..{after_sha} sur {local_path}: {e}")
            raise GitServiceError(f"Impossible de calculer le diff: {e}") from e

        changes: list[FileChange] = []

        for line in diff_index.splitlines():
            if not line.strip():
                continue

            parts = line.split("\t")
            status_code = parts[0]
            file_path = parts[-1]  # gère aussi le cas 'renamed' (3 colonnes)

            if file_path in exclude_paths:
                continue

            change_type = self._map_status_code(status_code)

            diff_excerpt = self._get_file_patch(repo, before_sha, after_sha, file_path)

            changes.append(FileChange(
                path=file_path,
                change_type=change_type,
                diff_excerpt=diff_excerpt,
            ))

        return changes

    def _map_status_code(self, code: str) -> str:
        mapping = {
            "A": "added",
            "M": "modified",
            "D": "deleted",
        }
        # 'R100' etc. pour renamed
        if code.startswith("R"):
            return "renamed"
        return mapping.get(code[0], "modified")

    def _get_file_patch(
        self, repo: Repo, before_sha: str, after_sha: str, file_path: str, max_chars: int = 1500
    ) -> str:
        """
        Récupère le patch détaillé d'un fichier précis, tronqué.
        Utilisé comme contexte pour l'IA (Diff Analyzer / README Updater),
        pas besoin du patch complet — juste assez pour comprendre l'intention.
        """
        try:
            patch = repo.git.diff(before_sha, after_sha, "--", file_path)
            return patch[:max_chars]
        except GitCommandError:
            return ""

    # ------------------------------------------------------------------
    # Commit + Push — utilisé par Sync Orchestrator après apply_patch()
    # ------------------------------------------------------------------
    def commit_and_push(
        self,
        local_path: str,
        file_paths: list[str],
        commit_message: str,
        author_name: str = "readme-bot",
        author_email: str = "readme-bot@yourapp.io",
        branch: Optional[str] = None,
        auth_token: Optional[str] = None,
    ) -> str:
        """
        git add + commit + push.

        author_name/author_email : identité dédiée du bot — c'est ce qui permet
        au Commit Detector de filtrer ses propres commits (anti-loop).

        Retourne le SHA du nouveau commit.
        """
        repo = self._open_repo(local_path)

        try:
            repo.index.add(file_paths)

            if not repo.index.diff("HEAD"):
                logger.info("Aucun changement à committer.")
                return repo.head.commit.hexsha

            author = f"{author_name} <{author_email}>"
            commit = repo.index.commit(
                commit_message,
                author=author,
                committer=author,
            )

            if auth_token:
                self._inject_token_in_remote(repo, auth_token)

            origin = repo.remotes.origin
            target_branch = branch or repo.active_branch.name
            origin.push(refspec=f"HEAD:refs/heads/{target_branch}")

            return commit.hexsha

        except GitCommandError as e:
            logger.error(f"Échec commit/push sur {local_path}: {e}")
            raise GitServiceError(f"Impossible de committer/pusher: {e}") from e

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _open_repo(self, local_path: str) -> Repo:
        try:
            return Repo(local_path)
        except (InvalidGitRepositoryError, NoSuchPathError) as e:
            raise GitServiceError(f"Clone local introuvable ou invalide: {local_path}") from e

    def get_current_head_sha(self, local_path: str) -> str:
        repo = self._open_repo(local_path)
        return repo.head.commit.hexsha