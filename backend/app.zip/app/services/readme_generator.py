"""
README Generator — Phase 1, génération initiale complète.

Distinct de readme_updater.py : ce service ne fait PAS de patch partiel,
il produit le README complet à partir de zéro, une seule fois,
au moment où le repository est ajouté.
"""

import logging

from app.services.ai_service import AIService, AIServiceError
from app.services.analyzer_service import ProjectAnalysis
from app.utils.markdown_renderer import render_readme

logger = logging.getLogger(__name__)


class ReadmeGeneratorError(Exception):
    pass


class ReadmeGeneratorService:
    def __init__(self, ai_service: AIService, readme_repository, readme_version_repository):
        self.ai_service = ai_service
        self.readme_repository = readme_repository
        self.readme_version_repository = readme_version_repository

    def generate_initial_readme(self, repository_id: str, project_name: str, analysis: ProjectAnalysis) -> dict:
        """
        Génère et persiste le premier README d'un repository.
        Retourne le sections_json généré.
        """
        project_context = {
            "project_name": project_name,
            "languages": analysis.languages,
            "frameworks": analysis.frameworks,
            "dependencies": analysis.dependencies,
            "file_structure": analysis.file_structure,
            "install_scripts": analysis.install_scripts,
            "run_scripts": analysis.run_scripts,
        }

        try:
            sections_json = self.ai_service.generate_full_readme(project_context)
        except AIServiceError as e:
            logger.error(f"Échec génération README initial pour repo {repository_id}: {e}")
            raise ReadmeGeneratorError(f"Impossible de générer le README initial: {e}") from e

        rendered_md = render_readme(sections_json)

        self.readme_repository.create(
            repository_id=repository_id,
            sections_json=sections_json,
            content_md=rendered_md,
        )

        self.readme_version_repository.create(
            repository_id=repository_id,
            sections_json=sections_json,
            content_md=rendered_md,
            triggered_by="initial_generation",
        )

        return sections_json